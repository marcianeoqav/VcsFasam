<!--
/*
	This JavaScript document contains JS function for The Mind Project's website.
*/


/*
	Pops up a window of specified height and width containing the 
	target_path.  Window has no toolbar, menu options, scrollbars,
	etc.
*/
function javaPopUp( target_page, wWidth, hHeight )
{
	options = "toolbar=no, menubar=no, status=no, resizable=yes, scrollbars=no, width=" + wWidth + ", height=" + hHeight;
	window.open( target_page, "", options );
}

function popUpHelp( URL ) 
{
		day = new Date();
		id = day.getTime();
		eval( "page" + id + " = window.open( URL, '" + id + 
					"', 'toolbar=0,scrollbars=1,location=0,statusbar=0,menubar=0,resizable=1,width=700,height=600,top=100,left=100');");
}
/*
	Pops up a window of specified height and width containing the 
	target_path.  Window has no toolbar, menu options, scrollbars, 
	etc., and is not resizable.
*/
function javaPopUpLocked( target_page, wWidth, hHeight )
{
	options = "toolbar=no, menubar=no, status=no, resizable=no, scrollbars=no, width=" + wWidth + ", height=" + hHeight;
	
	window.open( target_page, "", options );
}


/*
	This function invokes the glossary system.  If 'term' is recognized as 
	a glossary word, a pop-up will open with the term and its definition.
*/
function glossary( term )
{
	wWidth = 575;
	WHeight = 320;
	
	target_page = "/usersSys/glossary/showDef.php?term=" + term;
	
	options = "toolbar=no,width=" + wWidth + ",height=" + WHeight + ",resizable=yes,scrollbars=yes";
	
	window.open( target_page, "", options );
}


/*
	This function is used to launch virtual labs in new, un-resizable window 
	without navigation buttons, scroll bars, menubars, toolbars, etc.
*/
function virtualLab( target_page, hHeight, wWidth )
{
	options = "toolbar=no, menubar=no, status=no, resizable=no, scrollbars=no, width=" + wWidth + ", height=" + hHeight;
	
	window.open( target_page, "", options );
}

function killEnterKey()
{
	var nav = window.Event ? true : false;
	if (nav) 
	{
		window.captureEvents(Event.KEYDOWN);
		window.onkeydown = NetscapeEventHandler_KeyDown;
	} else 
	{
		document.onkeydown = MicrosoftEventHandler_KeyDown;
	}
}

function NetscapeEventHandler_KeyDown(e) 
{
	if (e.which == 13 && e.target.type != 'textarea' && e.target.type != 'submit') 
		return false; 
	return true;
}

function MicrosoftEventHandler_KeyDown() 
{
	if (event.keyCode == 13 && event.srcElement.type != 'textarea' && event.srcElement.type != 'submit')
		return false;
	return true;
}

// if state is true, checks all of the checkboxes within the division divID (<div class='divID'>)
// if state is false, unchecks all
function checkByDiv( divID, state ) 
{
    var collection = document.getElementById( divID ).getElementsByTagName( 'INPUT' );
    for( var x=0; x<collection.length; x++ )
    {
        if( collection[x].type.toUpperCase()=='CHECKBOX' )
            collection[x].checked = state;
    }
}

/*
	Set of helpful javascript functions.
	
	Some of these utility functions come from non-Mind Project sources.
	See below for credits.
*/

	// addEvent/removeEvent written by Dean Edwards, 2005
	// with input from Tino Zijdel
	// http://dean.edwards.name/weblog/2005/10/add-event/
	function addEvent(element, type, handler) 
	{
		// assign each event handler a unique ID
		if (!handler.$$guid) handler.$$guid = addEvent.guid++;
		// create a hash table of event types for the element
		if (!element.events) element.events = {};
		// create a hash table of event handlers for each element/event pair
		var handlers = element.events[type];
		if (!handlers) {
			handlers = element.events[type] = {};
			// store the existing event handler (if there is one)
			if (element["on" + type]) {
				handlers[0] = element["on" + type];
			}
		}
		// store the event handler in the hash table
		handlers[handler.$$guid] = handler;
		// assign a global event handler to do all the work
		element["on" + type] = handleEvent;
	};
	// a counter used to create unique IDs
	addEvent.guid = 1;
	function removeEvent(element, type, handler) 
	{
		// delete the event handler from the hash table
		if (element.events && element.events[type]) {
			delete element.events[type][handler.$$guid];
		}
	};
	function handleEvent(event) 
	{
		var returnValue = true;
		// grab the event object (IE uses a global event object)
		event = event || fixEvent(window.event);
		// get a reference to the hash table of event handlers
		var handlers = this.events[event.type];
		// execute each event handler
		for (var i in handlers) {
			this.$$handleEvent = handlers[i];
			if (this.$$handleEvent(event) === false) {
				returnValue = false;
			}
		}
		return returnValue;
	};
	function fixEvent(event) 
	{
		// add W3C standard event methods
		event.preventDefault = fixEvent.preventDefault;
		event.stopPropagation = fixEvent.stopPropagation;
		return event;
	};
	fixEvent.preventDefault = function() 
	{
		this.returnValue = false;
	};
	fixEvent.stopPropagation = function() 
	{
		this.cancelBubble = true;
	};
	

// Code: Robert T. Arrigo
// recursively creates a new, separate copy of an array
function returnArrayCopy( oldArray )
{
	if( ! ( oldArray.constructor.toString().indexOf( "Array" ) == -1 ) )
	{
		// array
		var newArray = oldArray.slice();
		for( var i = 0; i < newArray.length; i++ )
		{
			newArray[i] = returnArrayCopy( newArray[i] );
		}
		return newArray;
	} else
	{
		return oldArray;
	}
}

/*
	addslashes()
	FROM: http://kevin.vanzonneveld.net
*/
function addslashes( str ) 
{
    return str.replace(/("|'|\\)/g, "\\$1");
}

//-->
