function updateModAuthorField(fieldNum, profileGUI, profiles_array) {
	document.getElementById( "firstName" + fieldNum + "" ).value = profiles_array[profileGUI][0];
	document.getElementById( "middleName" + fieldNum + "").value = profiles_array[profileGUI][1]; 
	document.getElementById( "lastName" + fieldNum + "").value = profiles_array[profileGUI][2];
	document.getElementById( "profileGUI" + fieldNum + "").value = profileGUI;
}

function updateItemAuthorField(prefix, profileGUI, profiles_array) {
	document.getElementById( prefix + "firstName" ).value = profiles_array[profileGUI][0];
	document.getElementById( prefix + "middleName" ).value = profiles_array[profileGUI][1]; 
	document.getElementById( prefix + "lastName" ).value = profiles_array[profileGUI][2];
	document.getElementById( prefix + "profileGUI" ).value = profileGUI;
}

function updateProfileHolderField(userGUI, profiles_array) {
    if (userGUI > 0)
    {
        document.getElementById( "firstName" ).value = profiles_array[userGUI][0];
        document.getElementById( "middleName" ).value = profiles_array[userGUI][1]; 
        document.getElementById( "lastName" ).value = profiles_array[userGUI][2];
        document.getElementById( "email" ).value = profiles_array[userGUI][3];          
    }
    else
    {
        document.getElementById( "firstName" ).value = "";
        document.getElementById( "middleName" ).value = "";
        document.getElementById( "lastName" ).value = "";
        document.getElementById( "email" ).value = "";    
    }
 
}
