$(function(){
$("#headermenudesktop").append("<ul class=\"navspace menucel ativo3 dm-1\">\
<li><a href=\"http://www.devmedia.com.br/canais/\" rel=\"nofollow\" class=\"menulink\">Conte�do &nbsp;<small>&#9660;</small></a>\
<ul class=\"submenu\">\
<li><strong><a href=\"http://www.devmedia.com.br/forum/\">&raquo; F�rum</a></strong></li>\
<li><strong><a href=\"http://www.devmedia.com.br/mentoring/\">&raquo; Mentoring</a></strong></li>\
<li><a href=\"http://www.devmedia.com.br/front-end-web\">Front-end web</a></li>\
<li><a href=\"http://www.devmedia.com.br/mobile\">Mobile</a></li>\
<li><a href=\"http://www.devmedia.com.br/java\">Java</a></li>\
<li><a href=\"http://www.devmedia.com.br/dotnet\">.net</a></li>\
<li><a href=\"http://www.devmedia.com.br/banco-de-dados\">Banco de dados</a></li>\
<li><a href=\"http://www.devmedia.com.br/engenharia-de-software\">Engenharia de Software</a></li>\
<li><a href=\"http://www.devmedia.com.br/php\">PHP</a></li>\
<li><a href=\"http://www.devmedia.com.br/delphi\">Delphi</a></li>\
<a href=\"http://www.devmedia.com.br/canais/\" class=\"btn-dm-nav\">Todo o conte�do</a>\
</ul>\
</li>\
</ul>\
<ul class=\"navspace menucel ativo dm-1\">\
<li><a href=\"http://www.devmedia.com.br/assgold\" rel=\"nofollow\" class=\"menulink\">Revistas &nbsp;<small>&#9660;</small></a>\
<ul class=\"submenu\">\
<li><a href=\"http://www.devmedia.com.br/revista-front-end-magazine\">Front-end Magazine</a></li>\
<li><a href=\"http://www.devmedia.com.br/revista-mobile-magazine\">Mobile magazine</a></li>\
<li><a href=\"http://www.devmedia.com.br/revista-java-magazine\">Java Magazine</a></li>\
<li><a href=\"http://www.devmedia.com.br/revista-easy-java-magazine\">easy Java Magazine</a></li>\
<li><a href=\"http://www.devmedia.com.br/revista-dotnet-magazine\">.net Magazine</a></li>\
<li><a href=\"http://www.devmedia.com.br/revista-easy-dotnet-magazine\">easy .net Magazine</a></li>\
<li><a href=\"http://www.devmedia.com.br/revista-sql-magazine\">SQL Magazine</a></li>\
<li><a href=\"http://www.devmedia.com.br/revista-engenharia-de-software-magazine\">Engenharia de Software Magazine</a></li>\
<li><a href=\"http://www.devmedia.com.br/revista-clubedelphi\">ClubeDelphi</a></li>\
<a href=\"http://www.devmedia.com.br/assgold\" class=\"btn-dm-nav\">Todas as revistas</a>\
</ul>\
</li>\
</ul>\
<ul class=\"navspace menucel ativo3 dm-3\">\
<li><a href=\"http://www.devmedia.com.br/cursos/\" rel=\"nofollow\" class=\"menulink\">Cursos &nbsp;<small>&#9660;</small></a>\
<ul class=\"submenu\">\
<li><strong><a href=\"http://www.devmedia.com.br/cursos/formacoes/\">&raquo; Forma��es completas</a></strong></li>\
<li><a href=\"http://www.devmedia.com.br/cursos/front-end-web\">Cursos de front-end web</a></li>\
<li><a href=\"http://www.devmedia.com.br/cursos/mobile\">Cursos de Mobile</a></li>\
<li><a href=\"http://www.devmedia.com.br/cursos/java\">Cursos de Java</a></li>\
<li><a href=\"http://www.devmedia.com.br/cursos/net\">Cursos de .net</a></li>\
<li><a href=\"http://www.devmedia.com.br/cursos/banco-de-dados\">Cursos de Banco de dados</a></li>\
<li><a href=\"http://www.devmedia.com.br/cursos/engenharia-de-software\">Cursos de Engenharia de Software</a></li>\
<li><a href=\"http://www.devmedia.com.br/cursos/php\">Cursos de PHP</a></li>\
<li><a href=\"http://www.devmedia.com.br/cursos/automacao\">Cursos de Automa��o / NFe / Paf-ecf</a></li>\
<li><a href=\"http://www.devmedia.com.br/cursos/delphi\">Cursos de Delphi</a></li>\
<a href=\"http://www.devmedia.com.br/cursos/\" class=\"btn-dm-nav\">Todos os cursos</a></li>\
</ul>\
</li>\
</ul>\
<ul class=\"menucel dm-4\"><li><a href=\"http://www.devmedia.com.br/pocket-video\" class=\"menulink2\">Pocket Videos</a></li></ul>\
<ul class=\"menucel dm-5\"><li><a href=\"http://www.devmedia.com.br/api/\" rel=\"nofollow\" class=\"menulink2\" style=\"text-transform:none;\">APIs</a></li></ul>\
<ul class=\"menucel dm-5\"><li><a href=\"http://www.devmedia.com.br/guias/\" class=\"menulink2\">Guias <img border=\"0\" valign=\"middle\" style=\"margin-top:-2px;\" src=\"http://www.devmedia.com.br/imagens/2013/new.png\"></a></li></ul>\
<ul class=\"menucel dm-6\"><li><strong><a href=\"http://www.devmedia.com.br/mvp/\" class=\"menulink2\">MVP</a></strong></li></ul>");
});